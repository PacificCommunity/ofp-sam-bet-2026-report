# BET Figure 66 standalone reader

Unzip this folder and use Make plus base R. No Python, R packages, Git or network
connection is required. System tar with XZ support, stat and a SHA-256 utility
(sha256sum or shasum) are required. MFCL runs only on Linux x86-64.

```sh
make list
make verify
make prepare CASE=all OUT=/tmp/bet-inputs
make rerun CASE=all OUT=/tmp/bet-figure66
```

Choose reference, longline, pole_line, ps, ps_associated, ps_unassociated,
miscellaneous, all_off, or all. Use a fresh absolute OUT each time; on macOS use
/private/tmp rather than the symlink /tmp. Preparation checks the exact offline
files and stages final.par, all six MFCL inputs, mfclo64, the original doitall.sh,
and controls.txt for removal cases. saved-inputs.csv records bytes/modes/hashes.

Rerunning evaluates each saved PAR once and requires the complete native REP to
match its original SHA-256. The reference objective must agree within 1e-6 and
all cases must retain the original active parameter count. Cases run sequentially.
Logs and native-check.csv receipts remain in OUT; all adds native-checks.csv.
The receipt states the prescribed ceiling of one, not a measured native counter.

An explicit new original Diagnostic fit is available with:

```sh
make fullfit CASE=reference OUT=/tmp/bet-diagnostic-fullfit
```

The exact pinned doitall.sh starts from ordinary bet.ini -makepar. Its controls
are embedded; no external conf or selectivity CSV is needed. Full fitting is
supported only for reference. No new full fit was run or its equivalence assessed
when preparing this kit. The historical external engine hash remains unknown.

The CSV manifests and unchanged original JSON recipe retain repository/commit/path
provenance and the eight complete REP hashes. The native tar XZ contains regular
files, sharing engine and inputs once; the 45-byte native.tar.gz is the unchanged
legacy placeholder. Preparation rejects existing OUT and static symbolic links,
and verifies copied bytes. It has no descriptor-held protection against concurrent
namespace replacement. Use a private output parent.

Standalone make verify checks native kit integrity. Published report files and
document-build tools are outside this kit; report checkout make verify additionally
checks all 209 preserved assessment files and its existing R report audits.
